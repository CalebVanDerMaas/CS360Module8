package com.example.project2final;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void LineDataSet(List<Entry> entries, String label) {
        LineChart chart = (LineChart) findViewById(R.id.chart);
        List<Entry> xVals = new ArrayList<Entry>();
        List<Entry> yVals = new ArrayList<Entry>();

        Entry c1e1 = new Entry(0f, 100000f);
        xVals.add(c1e1);
        Entry c1e2 = new Entry(1f, 140000f);
        xVals.add(c1e2);

        Entry c2e1 = new Entry(0f, 130000f);
        yVals.add(c2e1);
        Entry c2e2 = new Entry(1f, 115000f);
        yVals.add(c2e2);

        LineDataSet setComp1 = new LineDataSet(xVals, "Company 1");
        setComp1.setAxisDependency(YAxis.AxisDependency.LEFT);
        LineDataSet setComp2 = new LineDataSet(yVals, "Company 2");
        setComp2.setAxisDependency(YAxis.AxisDependency.LEFT);

        List<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
        dataSets.add(setComp1);
        dataSets.add(setComp2);



        LineData data = new LineData(dataSets);
        chart.setData(data);
        chart.invalidate();

    }

}